import React, { useEffect, useRef, useState } from "react";
import {
  AccessibilityInfo,
  Animated,
  AppState,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { gameTheme } from "../theme/gameTheme";

type SplashScreenProps = {
  onFinish: () => void;
};

const SPLASH_DURATION_MS = 2200;
const { colors } = gameTheme;

export default function SplashScreen({ onFinish }: SplashScreenProps) {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(12)).current;

  const onFinishRef = useRef(onFinish);
  const finishedRef = useRef(false);

  const [introElapsed, setIntroElapsed] = useState(false);

  useEffect(() => {
    onFinishRef.current = onFinish;
  }, [onFinish]);

  useEffect(() => {
    let disposed = false;
    let animation: Animated.CompositeAnimation | undefined;

    async function animateIntro() {
      let reduceMotion = false;

      try {
        reduceMotion = await AccessibilityInfo.isReduceMotionEnabled();
      } catch {
        // اگر خواندن تنظیمات در دسترس نبود،
        // از انیمیشن سادهٔ پیش‌فرض استفاده می‌کنیم.
      }

      if (disposed) {
        return;
      }

      if (reduceMotion) {
        opacity.setValue(1);
        translateY.setValue(0);
        return;
      }

      animation = Animated.parallel([
        Animated.timing(opacity, {
          toValue: 1,
          duration: 650,
          useNativeDriver: true,
        }),
        Animated.timing(translateY, {
          toValue: 0,
          duration: 650,
          useNativeDriver: true,
        }),
      ]);

      animation.start();
    }

    void animateIntro();

    const timer = setTimeout(() => {
      setIntroElapsed(true);
    }, SPLASH_DURATION_MS);

    return () => {
      disposed = true;
      clearTimeout(timer);
      animation?.stop();
    };
  }, [opacity, translateY]);

  useEffect(() => {
    if (!introElapsed) {
      return;
    }

    function finishIfActive() {
      if (AppState.currentState !== "active" || finishedRef.current) {
        return;
      }

      finishedRef.current = true;
      onFinishRef.current();
    }

    const subscription = AppState.addEventListener("change", finishIfActive);

    finishIfActive();

    return () => subscription.remove();
  }, [introElapsed]);

  return (
    <View style={styles.container}>
      <StatusBar hidden />

      {/* پس‌زمینهٔ تزئینی؛ بدون تصویر یا وابستگی خارجی */}
      <View
        pointerEvents="none"
        accessible={false}
        style={StyleSheet.absoluteFillObject}
      >
        <View style={styles.rightPanel} />
        <View style={styles.diagonalStripe} />

        <View style={styles.topLine} />
        <View style={styles.bottomLine} />

        <View style={[styles.corner, styles.topLeftCorner]} />
        <View style={[styles.corner, styles.bottomRightCorner]} />
      </View>

      <Animated.View
        style={[
          styles.brand,
          {
            opacity,
            transform: [{ translateY }],
          },
        ]}
      >
        <View style={styles.emblem} accessible={false} pointerEvents="none">
          <View style={styles.emblemInner} />
          <View style={styles.crosshairHorizontal} />
          <View style={styles.crosshairVertical} />
          <View style={styles.crosshairDot} />
        </View>

        <Text
          accessibilityRole="header"
          accessibilityLabel="Strike Zone"
          numberOfLines={1}
          adjustsFontSizeToFit
          style={styles.title}
        >
          STRIKE<Text style={styles.titleAccent}>ZONE</Text>
        </Text>

        <View style={styles.separator} />

        <Text style={styles.tagline}>ENTER THE BATTLEFIELD</Text>
      </Animated.View>

      <View style={styles.footer}>
        <View style={styles.footerDot} />
        <Text style={styles.footerText}>LOCAL COMBAT · SINGLE PLAYER</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },

  rightPanel: {
    position: "absolute",
    top: "-40%",
    bottom: "-40%",
    right: "-15%",
    width: "50%",
    backgroundColor: colors.panelDark,
    transform: [{ rotate: "22deg" }],
  },

  diagonalStripe: {
    position: "absolute",
    top: "-40%",
    bottom: "-40%",
    right: "28%",
    width: 2,
    backgroundColor: colors.accentSoft,
    transform: [{ rotate: "22deg" }],
  },

  topLine: {
    position: "absolute",
    top: 22,
    left: "9%",
    right: "9%",
    height: 1,
    backgroundColor: colors.border,
    opacity: 0.45,
  },

  bottomLine: {
    position: "absolute",
    bottom: 22,
    left: "9%",
    right: "9%",
    height: 1,
    backgroundColor: colors.border,
    opacity: 0.45,
  },

  corner: {
    position: "absolute",
    width: 30,
    height: 30,
    borderColor: colors.accent,
    opacity: 0.75,
  },

  topLeftCorner: {
    top: 35,
    left: 35,
    borderTopWidth: 2,
    borderLeftWidth: 2,
  },

  bottomRightCorner: {
    right: 35,
    bottom: 35,
    borderRightWidth: 2,
    borderBottomWidth: 2,
  },

  brand: {
    alignItems: "center",
    width: "76%",
    maxWidth: 640,
  },

  emblem: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: colors.accent,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 14,
  },

  emblemInner: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: colors.border,
  },

  crosshairHorizontal: {
    position: "absolute",
    width: 78,
    height: 1,
    backgroundColor: colors.accent,
  },

  crosshairVertical: {
    position: "absolute",
    width: 1,
    height: 78,
    backgroundColor: colors.accent,
  },

  crosshairDot: {
    position: "absolute",
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.accent,
  },

  title: {
    color: colors.text,
    fontSize: 54,
    fontWeight: "900",
    letterSpacing: 4,
    textAlign: "center",
  },

  titleAccent: {
    color: colors.accent,
  },

  separator: {
    width: 64,
    height: 3,
    backgroundColor: colors.accent,
    marginTop: 12,
    marginBottom: 12,
  },

  tagline: {
    color: colors.textMuted,
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 3,
    textAlign: "center",
  },

  footer: {
    position: "absolute",
    bottom: 35,
    left: "15%",
    right: "15%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },

  footerDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: colors.accent,
    marginRight: 8,
  },

  footerText: {
    color: colors.textMuted,
    fontSize: 9,
    letterSpacing: 1.5,
    textAlign: "center",
  },
});
