import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { getLanAddresses, type LanAddress } from "../network/LanAddress";
import { LAN_PORT } from "../network/LanConnection";

export default function HostAddressPanel() {
  const [addresses, setAddresses] = useState<LanAddress[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const mountedRef = useRef(false);
  const requestRef = useRef(0);

  const refresh = useCallback(async () => {
    const requestId = ++requestRef.current;

    setLoading(true);
    setError(null);
    setAddresses([]);

    try {
      const result = await getLanAddresses();

      if (mountedRef.current && requestId === requestRef.current) {
        setAddresses(result);
      }
    } catch (cause) {
      if (mountedRef.current && requestId === requestRef.current) {
        setError(
          cause instanceof Error
            ? cause.message
            : "خواندن آدرس‌های شبکه ناموفق بود.",
        );
      }
    } finally {
      if (mountedRef.current && requestId === requestRef.current) {
        setLoading(false);
      }
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    void refresh();

    return () => {
      mountedRef.current = false;
      requestRef.current++;
    };
  }, [refresh]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>آدرس‌های پیشنهادی میزبان</Text>

      <Text style={styles.hint}>
        ابتدا هات‌اسپات را روشن کن. مهمان باید به همان شبکه وصل باشد و فقط IP را
        در Join Room وارد کند.
      </Text>

      {loading && <ActivityIndicator color="#73e6a2" style={styles.loader} />}

      {!loading &&
        addresses.map((item) => (
          <View
            key={`${item.interfaceName}/${item.address}`}
            style={styles.addressCard}
          >
            <Text selectable style={styles.address}>
              {item.address}
            </Text>

            <Text selectable style={styles.interfaceName}>
              Interface: {item.interfaceName}
            </Text>
          </View>
        ))}

      {!loading && error === null && addresses.length === 0 && (
        <Text style={styles.hint}>
          هیچ آدرس IPv4 قابل‌نمایشی پیدا نشد. هات‌اسپات یا Wi-Fi را بررسی کن و
          دوباره به‌روزرسانی بزن.
        </Text>
      )}

      {error !== null && (
        <Text selectable style={styles.error}>
          {error}
        </Text>
      )}

      <Text style={styles.port}>TCP PORT: {LAN_PORT}</Text>

      <Text style={styles.hint}>
        این فهرست ممکن است شامل IP دیتای موبایل یا VPN هم باشد. آدرس درست، آدرس
        رابط مشترک با گوشی مهمان است. در حالت هات‌اسپات معمولاً با Gateway شبکهٔ
        Wi-Fi مهمان مطابقت دارد.
      </Text>

      <Pressable
        accessibilityRole="button"
        accessibilityState={{ disabled: loading }}
        disabled={loading}
        onPress={() => {
          void refresh();
        }}
        style={({ pressed }) => [
          styles.button,
          (loading || pressed) && styles.dimmed,
        ]}
      >
        <Text style={styles.buttonText}>
          {loading ? "در حال بررسی…" : "به‌روزرسانی آدرس‌ها"}
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 18,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: "#354f70",
  },

  title: {
    color: "#ffffff",
    fontSize: 15,
    fontWeight: "800",
    textAlign: "right",
  },

  hint: {
    color: "#9aabbe",
    fontSize: 11,
    lineHeight: 21,
    textAlign: "right",
    marginTop: 10,
  },

  loader: {
    marginVertical: 16,
  },

  addressCard: {
    backgroundColor: "#10151c",
    borderWidth: 1,
    borderColor: "#354f70",
    borderRadius: 10,
    padding: 12,
    marginTop: 12,
  },

  address: {
    color: "#73e6a2",
    fontSize: 22,
    fontWeight: "800",
    textAlign: "left",
    writingDirection: "ltr",
  },

  interfaceName: {
    color: "#9aabbe",
    fontSize: 11,
    marginTop: 6,
    textAlign: "left",
    writingDirection: "ltr",
  },

  port: {
    color: "#d6e0ec",
    fontSize: 11,
    textAlign: "left",
    marginTop: 12,
  },

  error: {
    color: "#ff8080",
    fontSize: 12,
    lineHeight: 22,
    textAlign: "right",
    marginTop: 12,
  },

  button: {
    borderWidth: 1,
    borderColor: "#73e6a2",
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
    marginTop: 14,
  },

  buttonText: {
    color: "#73e6a2",
    fontWeight: "700",
    fontSize: 12,
  },

  dimmed: {
    opacity: 0.5,
  },
});
