import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import WebView from "react-native-webview";
import { isGameMessage, type GameMessage } from "../protocol/gameProtocol";

import { createMultiplayerHtml } from "../game/createMultiplayerHtml";
import type { MatchPhase, MatchSession } from "../protocol/matchProtocol";

type Props = {
  session: MatchSession;
  phase: MatchPhase;
  onLoaded: (matchId: string) => void;
  onLeave: () => void;
  sendGameMessage: (message: GameMessage) => boolean;

  subscribeGameMessages: (
    listener: (message: GameMessage) => void,
  ) => () => void;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

export default function MultiplayerGameScreen({
  session,
  phase,
  onLoaded,
  onLeave,
  sendGameMessage,
  subscribeGameMessages,
}: Props) {
  const [error, setError] = useState<string | null>(null);
  const [localLoaded, setLocalLoaded] = useState(false);
  const webViewRef = useRef<WebView>(null);

  const injectBridgeCall = useCallback(
    (method: "start" | "receive", argument: unknown) => {
      const serialized = JSON.stringify(argument)
        .replace(/</g, "\\u003c")
        .replace(/\u2028/g, "\\u2028")
        .replace(/\u2029/g, "\\u2029");

      webViewRef.current?.injectJavaScript(`
      (function () {
        if (window.lanBridge) {
          window.lanBridge.${method}(${serialized});
        }
      })();
      true;
    `);
    },
    [],
  );

  useEffect(() => {
    return subscribeGameMessages((message) => {
      if (message.payload.matchId !== session.matchId) {
        return;
      }

      injectBridgeCall("receive", message);
    });
  }, [session.matchId, subscribeGameMessages, injectBridgeCall]);

  useEffect(() => {
    if (localLoaded && phase === "running" && !error) {
      injectBridgeCall("start", session.matchId);
    }
  }, [localLoaded, phase, error, session.matchId, injectBridgeCall]);

  const document = useMemo(() => {
    try {
      return {
        source: { html: createMultiplayerHtml(session) },
        error: null,
      };
    } catch (cause) {
      return {
        source: null,
        error: cause instanceof Error ? cause.message : String(cause),
      };
    }
  }, [session]);

  const handleMessage = useCallback(
    (data: string) => {
      let message: unknown;

      try {
        message = JSON.parse(data);
      } catch {
        return;
      }

      if (!isRecord(message)) {
        return;
      }

      // خطاهای diagnostics فعلی، از جمله شکست بارگذاری Three.js.
      if (message.type === "error" && typeof message.message === "string") {
        setError(message.message);
        return;
      }

      if (message.matchId !== session.matchId) {
        return;
      }
      if (message.type === "multiplayer/network") {
        if (
          isGameMessage(message.message) &&
          message.message.payload.matchId === session.matchId
        ) {
          sendGameMessage(message.message);
        }

        return;
      }

      if (message.type === "multiplayer/loaded") {
        setLocalLoaded(true);
        onLoaded(session.matchId);
        return;
      }

      if (
        message.type === "multiplayer/error" &&
        typeof message.message === "string"
      ) {
        setError(message.message);
      }
    },
    [session.matchId, onLoaded, sendGameMessage],
  );

  const displayedError = error ?? document.error;
  const showPreview = localLoaded && phase === "running" && !displayedError;

  return (
    <View style={styles.container}>
      {document.source && (
        <WebView
          ref={webViewRef}
          source={document.source}
          style={styles.webview}
          originWhitelist={["*"]}
          javaScriptEnabled
          domStorageEnabled
          scrollEnabled={false}
          bounces={false}
          overScrollMode="never"
          setSupportMultipleWindows={false}
          androidLayerType="hardware"
          onMessage={(event) => {
            handleMessage(event.nativeEvent.data);
          }}
          onError={(event) => {
            setError(event.nativeEvent.description);
          }}
          onRenderProcessGone={() => {
            setError("پردازش گرافیکی بازی متوقف شد.");
          }}
          onContentProcessDidTerminate={() => {
            setError("پردازش گرافیکی بازی متوقف شد.");
          }}
        />
      )}

      {/* تا اتصال ورودی شبکه‌ای، لمس کنترل‌های تک‌نفره مسدود است. */}
      <View
        style={[styles.overlay, showPreview && styles.previewOverlay]}
        pointerEvents={showPreview ? "box-none" : "auto"}
      >
        <View style={[styles.panel, showPreview && styles.previewPanel]}>
          {displayedError ? (
            <>
              <Text style={styles.errorTitle}>خطای آماده‌سازی بازی</Text>
              <Text style={styles.description}>{displayedError}</Text>
            </>
          ) : phase === "running" ? (
            <>
              <Text style={styles.title}>مسابقهٔ آزمایشی متصل است</Text>
              <Text style={styles.description}>
                حرکت و نگاه فعال است؛ شلیک هنوز فعال نیست.
              </Text>
            </>
          ) : (
            <>
              <ActivityIndicator color="#73e6a2" />
              <Text style={styles.title}>
                {localLoaded
                  ? "منتظر تأیید گوشی مقابل…"
                  : "در حال ساخت محیط بازی…"}
              </Text>
            </>
          )}

          <Text style={styles.description}>
            {session.role === "host" ? "نقش: میزبان" : "نقش: مهمان"}
          </Text>

          <Pressable
            accessibilityRole="button"
            style={styles.button}
            onPress={onLeave}
          >
            <Text style={styles.buttonText}>خروج از مسابقه</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#10151c",
  },
  webview: {
    flex: 1,
    backgroundColor: "#10151c",
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(16,21,28,0.65)",
    padding: 16,
  },
  panel: {
    width: "90%",
    maxWidth: 520,
    backgroundColor: "#182330",
    borderRadius: 14,
    padding: 18,
    alignItems: "center",
  },
  title: {
    color: "#73e6a2",
    fontSize: 16,
    fontWeight: "700",
    textAlign: "center",
    marginTop: 10,
  },
  errorTitle: {
    color: "#ff6464",
    fontSize: 16,
    fontWeight: "700",
  },
  description: {
    color: "#d6e0ec",
    fontSize: 12,
    lineHeight: 21,
    textAlign: "center",
    marginTop: 10,
  },
  button: {
    backgroundColor: "#354f70",
    borderRadius: 10,
    paddingHorizontal: 24,
    paddingVertical: 12,
    marginTop: 14,
  },
  buttonText: {
    color: "#ffffff",
    fontWeight: "700",
  },
  previewOverlay: {
    backgroundColor: "transparent",
    justifyContent: "flex-start",
    alignItems: "flex-end",
    padding: 8,
  },

  previewPanel: {
    width: 300,
    maxWidth: "90%",
    padding: 8,
    backgroundColor: "rgba(24,35,48,0.85)",
  },
});
