import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { LAN_PORT } from "../network/LanConnection";
import type { RoomStatus } from "../hooks/useLanRoom";
import LobbyPanel from "./LobbyPanel";
import HostAddressPanel from "../components/HostAddressPanel";
import MatchStartPanel from "../components/MatchStartPanel";
import type { MatchPhase } from "../protocol/matchProtocol";

type Props = {
  status: RoomStatus;
  error: string | null;
  onStartHosting: () => void;
  onLeave: () => void;
  peerVerified: boolean;
  guestReady: boolean;
  matchPhase: MatchPhase;
  canStartMatch: boolean;
  onStartMatch: () => void;
};

const STATUS_LABELS: Record<RoomStatus, string> = {
  idle: "Room not created yet",
  starting: "Creating room…",
  hosting: "Room ready — waiting for guest",
  connecting: "Connecting…",
  connected: "Guest connected",
  disconnected: "Connection lost",
};

export default function CreateRoomScreen({
  status,
  error,
  peerVerified,
  guestReady,
  onStartHosting,
  onLeave,
  matchPhase,
  canStartMatch,
  onStartMatch,
}: Props) {
  const [requested, setRequested] = useState(false);

  const waitingForServer = requested && status === "idle" && error === null;

  const canStart =
    !waitingForServer && (status === "idle" || status === "disconnected");

  const connected = status === "connected";

  function createRoom() {
    setRequested(true);
    onStartHosting();
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.eyebrow}>LOCAL MULTIPLAYER</Text>
          <Text style={styles.title}>Create Room</Text>
        </View>

        <Pressable
          accessibilityRole="button"
          onPress={onLeave}
          style={styles.backButton}
        >
          <Text style={styles.backText}>BACK / CLOSE ROOM</Text>
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.columns}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Network Setup</Text>

            <Text style={styles.instructions}>
              1. Turn on the host phone's hotspot.
              {"\n\n"}
              2. Connect the guest phone to the same hotspot.
              {"\n\n"}
              3. Tap "Create Room" and keep this app open.
              {"\n\n"}
              4. The guest must enter this phone's local IP in Join Room.
            </Text>

            <Text style={styles.hint}>
              The host IP is not auto-detected. On most phones it can be found
              under the Gateway address in the guest's Wi-Fi details — there is
              no universal fixed IP for all devices.
            </Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Room Status</Text>

            <Text
              accessibilityLiveRegion="polite"
              style={[styles.status, connected && styles.connectedStatus]}
            >
              {waitingForServer ? "Creating room…" : STATUS_LABELS[status]}
            </Text>

            <Text style={styles.details}>
              Port: {LAN_PORT}
              {"\n"}
              Capacity: 1 host + 1 guest
              {"\n"}
              Guest connected: {connected ? "1" : "0"} / 1
            </Text>
            <HostAddressPanel />

            {error !== null && (
              <Text
                accessibilityLiveRegion="polite"
                selectable
                style={styles.error}
              >
                {error}
              </Text>
            )}

            <Pressable
              accessibilityRole="button"
              accessibilityState={{ disabled: !canStart }}
              disabled={!canStart}
              onPress={createRoom}
              style={({ pressed }) => [
                styles.createButton,
                !canStart && styles.disabledButton,
                pressed && styles.pressedButton,
              ]}
            >
              <Text style={styles.createText}>
                {canStart ? "CREATE ROOM" : "ROOM RUNNING"}
              </Text>
            </Pressable>

            {connected && (
              <>
                {matchPhase === "lobby" && (
                  <LobbyPanel
                    role="host"
                    peerVerified={peerVerified}
                    guestReady={guestReady}
                  />
                )}

                <MatchStartPanel
                  role="host"
                  phase={matchPhase}
                  canStart={canStartMatch}
                  onStart={onStartMatch}
                />
              </>
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#10151c",
    paddingHorizontal: 24,
    paddingTop: 16,
  },

  header: {
    flexDirection: "row",
    direction: "ltr",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 16,
  },

  eyebrow: {
    color: "#9aabbe",
    fontSize: 10,
    letterSpacing: 2,
  },

  title: {
    color: "#ffffff",
    fontSize: 26,
    fontWeight: "900",
    marginTop: 4,
  },

  backButton: {
    borderWidth: 1,
    borderColor: "#354f70",
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },

  backText: {
    color: "#ffffff",
    fontSize: 12,
  },

  content: {
    paddingBottom: 24,
  },

  columns: {
    flexDirection: "row",
    direction: "ltr",
    gap: 16,
  },

  card: {
    flex: 1,
    minWidth: 0,
    backgroundColor: "#1a2431",
    borderWidth: 1,
    borderColor: "#354f70",
    borderRadius: 14,
    padding: 18,
  },

  cardTitle: {
    color: "#ffffff",
    fontSize: 17,
    fontWeight: "800",
    textAlign: "left",
    marginBottom: 14,
  },

  instructions: {
    color: "#d6e0ec",
    fontSize: 13,
    lineHeight: 22,
    textAlign: "left",
  },

  status: {
    color: "#f5c76b",
    fontSize: 16,
    fontWeight: "700",
    textAlign: "left",
    marginBottom: 12,
  },

  connectedStatus: {
    color: "#73e6a2",
  },

  details: {
    color: "#d6e0ec",
    fontSize: 13,
    lineHeight: 26,
    textAlign: "left",
  },

  hint: {
    color: "#9aabbe",
    fontSize: 11,
    lineHeight: 21,
    textAlign: "left",
    marginTop: 16,
  },

  error: {
    color: "#ff8080",
    fontSize: 12,
    lineHeight: 22,
    textAlign: "left",
    marginTop: 12,
  },

  createButton: {
    backgroundColor: "#73e6a2",
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: 14,
    marginTop: 18,
  },

  disabledButton: {
    opacity: 0.45,
  },

  pressedButton: {
    opacity: 0.8,
  },

  createText: {
    color: "#10151c",
    fontWeight: "800",
    fontSize: 14,
  },
});
