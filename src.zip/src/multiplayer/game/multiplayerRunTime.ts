export const multiplayerRuntimeScript = String.raw`
function createMultiplayerRuntime(session, config, post) {
  const THREE = window.THREE;
  const world = createWorld(THREE, config);
  const controls = createControls(world, config);

  // مخفی‌کردن دشمن‌های تک‌نفره، بدون حذف از scene.
  // world.dispose همچنان منابع آن‌ها را آزاد می‌کند.
  if (Array.isArray(world.enemies)) {
    world.enemies.forEach(function (enemy) {
      if (enemy.group) {
        enemy.group.visible = false;
      }
    });
  }

  if (world.target) {
    world.target.visible = false;
  }

  const isHost = session.role === "host";
  const localId = isHost ? "host" : "guest";

  const simulation = isHost
    ? createHostSimulation(world, config)
    : null;

  let running = false;
  let disposed = false;
  let frameId = 0;
  let previousTime = performance.now();
  let sendElapsed = 0;
  let inputSequence = 0;
  let lastSnapshotSequence = 0;

  // موتور و مبارزهٔ تک‌نفره ساخته نمی‌شوند.
  window.togglePause = function () {};
  window.switchMap = function () {};

  // کنترل‌های پشتیبانی‌نشده در این مرحله.
  [
    "playPauseBtn",
    "pauseMenu",
    "fireButton",
    "gameOver"
  ].forEach(function (id) {
    const element = document.getElementById(id);

    if (element) {
      element.style.display = "none";
    }
  });

  // مدل سادهٔ بازیکن مقابل.
  const avatar = new THREE.Group();

  const body = new THREE.Mesh(
    new THREE.CylinderGeometry(0.3, 0.3, 1.15, 12),
    new THREE.MeshStandardMaterial({
      color: isHost ? 0x53a8ff : 0xffa34d
    })
  );

  body.position.y = 0.75;
  avatar.add(body);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.23, 12, 8),
    new THREE.MeshStandardMaterial({
      color: 0xf2c6a0
    })
  );

  head.position.y = 1.5;
  avatar.add(head);

  // نشانهٔ جهت نگاه بازیکن مقابل.
  const direction = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.12, 0.35),
    new THREE.MeshStandardMaterial({
      color: 0x222222
    })
  );

  direction.position.set(0, 1.5, -0.3);
  avatar.add(direction);

  avatar.visible = false;
  world.scene.add(avatar);

  // آخرین موقعیت‌های معتبر دریافت‌شده از شبیه‌سازی میزبان.
  const localTarget = new THREE.Vector3();
  const remoteTarget = new THREE.Vector3();

  let hasLocalState = false;
  let hasRemoteState = false;
  let remoteYaw = 0;

  function shortestAngleDifference(from, to) {
    return Math.atan2(
      Math.sin(to - from),
      Math.cos(to - from)
    );
  }

  function updatePresentation(delta) {
    // مهمان فقط نمایش موقعیت خودش را نرم می‌کند.
    // موقعیت واقعی همچنان روی میزبان محاسبه می‌شود.
    if (!isHost && hasLocalState) {
      if (world.camera.position.distanceToSquared(localTarget) > 9) {
        // اختلاف بیشتر از 3 متر: انتقال مستقیم.
        world.camera.position.copy(localTarget);
      } else {
        const alpha = 1 - Math.exp(-25 * delta);
        world.camera.position.lerp(localTarget, alpha);
      }
    }

    // نرم‌کردن حرکت و چرخش بازیکن مقابل.
    if (hasRemoteState) {
      if (avatar.position.distanceToSquared(remoteTarget) > 9) {
        avatar.position.copy(remoteTarget);
        avatar.rotation.y = remoteYaw;
      } else {
        const alpha = 1 - Math.exp(-18 * delta);

        avatar.position.lerp(remoteTarget, alpha);

        avatar.rotation.y += shortestAngleDifference(
          avatar.rotation.y,
          remoteYaw
        ) * alpha;
      }
    }
  }

  function applySnapshot(message) {
    const payload = message.payload;

    if (
      payload.matchId !== session.matchId ||
      payload.sequence <= lastSnapshotSequence
    ) {
      return;
    }

    lastSnapshotSequence = payload.sequence;

    payload.players.forEach(function (player) {
      if (player.id === localId) {
        localTarget.set(
          player.position.x,
          player.position.y,
          player.position.z
        );

        // میزبان از موقعیت شبیه‌سازی‌شدهٔ همین فریم استفاده می‌کند.
        // اولین وضعیت مهمان نیز بدون انیمیشن اعمال می‌شود.
        if (isHost || !hasLocalState) {
          world.camera.position.copy(localTarget);
        }

        hasLocalState = true;

        // جهت نگاه محلی را از snapshot بازنویسی نمی‌کنیم.
        return;
      }

      // موقعیت شبکه ارتفاع چشم است؛ مدل از سطح زمین شروع می‌شود.
      remoteTarget.set(
        player.position.x,
        player.position.y - config.player.eyeHeight,
        player.position.z
      );

      remoteYaw = player.yaw;

      if (!hasRemoteState) {
        avatar.position.copy(remoteTarget);
        avatar.rotation.y = remoteYaw;
      }

      hasRemoteState = true;
      avatar.visible = true;
    });
  }

  function sampleInput() {
    return {
      moveX: controls.input.x,
      moveZ: controls.input.y,
      yaw: world.camera.rotation.y,
      pitch: world.camera.rotation.x,
      jump: false,
      fire: false
    };
  }

  function receive(message) {
    if (
      disposed ||
      !message ||
      !message.payload ||
      message.payload.matchId !== session.matchId
    ) {
      return;
    }

    if (isHost && message.type === "game/input") {
      simulation.setInput(
        "guest",
        message.payload.input,
        message.payload.sequence,
        performance.now()
      );
    }

    if (!isHost && message.type === "game/snapshot") {
      applySnapshot(message);
    }
  }

  function start() {
    if (disposed || running) return;

    controls.reset();
    previousTime = performance.now();
    sendElapsed = 0;
    running = true;
  }

  function frame(now) {
    if (disposed) return;

    try {
      const delta = Math.max(
        0,
        Math.min((now - previousTime) / 1000, 0.1)
      );

      previousTime = now;

      if (running) {
        sendElapsed += delta;

        let currentSnapshot = null;

        if (isHost) {
          inputSequence += 1;

          simulation.setInput(
            "host",
            sampleInput(),
            inputSequence,
            now
          );

          simulation.advance(delta, now);

          // نمایش میزبان در هر فریم به‌روز می‌شود،
          // نه فقط هنگام ارسال پیام شبکه.
          currentSnapshot = simulation.snapshot(session.matchId);
          applySnapshot(currentSnapshot);
        }

        // نرخ ارسال شبکه حداکثر 20 پیام در ثانیه است.
        // پس از وقفه، پیام‌های عقب‌افتاده انباشته ارسال نمی‌شوند.
        if (sendElapsed >= 0.05) {
          sendElapsed %= 0.05;

          if (isHost) {
            post("multiplayer/network", {
              message: currentSnapshot
            });
          } else {
            inputSequence += 1;

            post("multiplayer/network", {
              message: {
                type: "game/input",
                payload: {
                  matchId: session.matchId,
                  sequence: inputSequence,
                  input: sampleInput()
                }
              }
            });
          }
        }

        // نرم‌سازی نمایش مستقل از نرخ دریافت پیام شبکه.
        updatePresentation(delta);
      }

      world.renderer.render(world.scene, world.camera);
      frameId = requestAnimationFrame(frame);
    } catch (error) {
      running = false;

      post("multiplayer/error", {
        message: error instanceof Error
          ? error.message
          : String(error)
      });
    }
  }

  function resetInput() {
    controls.reset();
  }

  function dispose() {
    if (disposed) return;

    disposed = true;
    running = false;

    cancelAnimationFrame(frameId);

    window.removeEventListener("resize", world.resize);
    window.removeEventListener("blur", resetInput);
    document.removeEventListener("visibilitychange", resetInput);

    controls.dispose();
    world.dispose();
  }

  window.addEventListener("resize", world.resize);
  window.addEventListener("blur", resetInput);
  document.addEventListener("visibilitychange", resetInput);

  world.resize();
  world.renderer.render(world.scene, world.camera);

  frameId = requestAnimationFrame(frame);

  return {
    start: start,
    receive: receive,
    dispose: dispose
  };
}
`;
